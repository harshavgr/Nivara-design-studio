// In dev, Vite proxies /api to the Express server (see vite.config.js).
// In production, set VITE_API_URL to your deployed API's base URL
// (e.g. https://api.nivaradesignstudio.com) in a client/.env file.
const API_BASE = import.meta.env.VITE_API_URL || "";

export async function submitEnquiry(payload) {
  const res = await fetch(`${API_BASE}/api/contact`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || "Something went wrong. Please try again.");
  }

  return data;
}

export async function fetchPortfolio(category) {
  const query = category && category !== "All" ? `?category=${encodeURIComponent(category)}` : "";
  const res = await fetch(`${API_BASE}/api/portfolio${query}`);

  if (!res.ok) {
    throw new Error("Could not load portfolio right now.");
  }

  return res.json();
}

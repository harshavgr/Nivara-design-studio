import React from "react";
import { Link } from "react-router-dom";
import Logo from "../components/Logo.jsx";
import "./Home.css";

export default function Home() {
  return (
    <section className="hero">
      <div className="hero__blob" aria-hidden="true" />
      <div className="container hero__inner">
        <Logo variant="full" size="lg" />

        <span className="eyebrow eyebrow--center hero__eyebrow">
          <span className="eyebrow-line" />
          Spaces That Inspire
          <span className="eyebrow-line" />
        </span>

        <h1 className="hero__title">
          Where beauty
          <br />
          <em>meets</em> intention.
        </h1>

        <p className="hero__subtitle">
          Thoughtful interiors crafted around the way you live — elegant,
          purposeful, and distinctly yours.
        </p>

        <div className="hero__actions">
          <Link to="/portfolio" className="btn btn-primary">
            View Portfolio
          </Link>
          <Link to="/contact" className="btn btn-outline">
            Get In Touch
          </Link>
        </div>
      </div>
    </section>
  );
}
